# Galaxy Watch8 AMOLED 快捷表盘 — GitHub 一键编译

此工程为 **Wear OS Watch Face Format v2** 表盘：黑色背景、yyyy/MM/dd 日期、大号24小时数字时间、底部电池百分比、8个可配置的快捷位置。

## 方式 A：源代码工程上传 GitHub
1. 在 GitHub 新建 repository，建议命名 `watch8-amoled-face`，勾选 Add a README file，默认分支 `main`。
2. **解压** `Watch8_GitHub_Actions_完整工程.zip`，将解压后文件夹里的内容（`app/`, `.github/`, Gradle 配置等）上传至仓库**根目录**，不要只把 ZIP 文件上传 GitHub。GitHub 不会自动解压仓库里的 ZIP。
3. 仓库上方选择 Actions → `Build Galaxy Watch8 APK` → `Run workflow`。向 `main` 提交代码也可以自动启动。
4. 编译显示绿色勾后，打开本次运行记录，在 **Artifacts** 下载 `Watch8-AMOLED-ShortcutFace-APK`；解压后得到 `app-debug.apk`。
5. APK 需要安装到 Galaxy Watch8 **手表**（而非手机）。可通过 ADB 无线调试等方式安装。安装后长按当前表盘，选择本表盘并自定义 8 个快捷位置。

## 方式 B：只上传一个工作流文件，适合仅使用手机
使用配套的 `Watch8_手机端_单文件编译.yml`，不必上传整个 Android Studio 工程。
1. 在 GitHub 新建带 README 的仓库。
2. 仓库选择 Add file → Create new file，文件名称填 `.github/workflows/build.yml`。
3. 打开下载的 `Watch8_手机端_单文件编译.yml`，**复制全部内容**粘贴到 GitHub 文件编辑器并 Commit changes。
4. 进入 Actions → `Build Galaxy Watch8 APK (single file)` → Run workflow；构建通过后从 Artifacts 下载 ZIP，再解压得到 `app-debug.apk`。
5. 单文件工作流内部已经嵌入相同项目资源，编译时自动还原，仓库不需要另外上传 ZIP。

## 注意事项
- GitHub 运行器在线下载 Android SDK、Gradle 和依赖。必须允许 GitHub Actions，第一次构建会下载依赖。
- 这是 **debug APK**，用于个人测试和安装；不是 Google Play 上架的签名发行包。
- 此项目使用 WFF 2：实际可配置的应用快捷入口取决于手表是否提供 `App shortcut` 数据源。只有可用数据源/应用才能被选择，点击动作由系统数据源管理。不是通用应用启动器，无法保证任意第三方应用都能添加。
- GitHub Actions 可完成 Android APK 编译，**不等于**经过手表实机运行或官方 WFF XSD 校验。编译通过后仍建议在手表上测试。
- 原生 WFF 上限为 8 个 `ComplicationSlot`。常亮显示会隐藏彩色图标；如需完全关闭常亮，在手表系统显示设置关闭 AOD。

## 构建信息
- Android Gradle Plugin: 8.9.2
- Gradle: 8.11.1
- Java: 17
- compileSdk/targetSdk: 35
- minSdk: 34
- WFF: 2
- APK: `app/build/outputs/apk/debug/app-debug.apk`
