# Watch8 AMOLED Shortcut Face — Galaxy Watch8 表盘

真实 Wear OS **Watch Face Format (WFF 2)** 表盘项目，不是图片壁纸，也不是普通启动器 Activity。
适用于 Galaxy Watch8 及其他 Wear OS 5 / 6 系列（需运行 API 34 及以上）。

## 特性
- 黑色 `#000000` 背景（AMOLED 黑色像素不发光）
- 保持原参考图的 **yyyy/MM/dd 日期 + 大号 24 小时时钟 HH:mm**
- 下方 **BAT 86%** 为实时手表电池百分比，点击电池显示进入系统电池页面
- 8 个 **独立选择的应用快捷图标位置**；点击已配置的图标打开对应手表 App
- 快捷位置使用 Wear OS 原生的 **App shortcut complication**，可以选择手表中安装的应用
- 未配置的位置显示 `+`，支持空位置；不需要手机伴侣程序或额外权限
- 常亮/环境模式自动隐藏彩色快捷图标以降低耗电，手表自身可关闭 AOD

## 编译（Android Studio）
1. 在电脑上安装 Android Studio（建议包含 Android SDK Platform 36 和 Android Gradle Plugin 8.9.2，JDK 17）。
2. `File > Open` 打开本项目根目录 `Watch8_AMOLED_ShortcutFace`。
3. 等待 Gradle Sync 下载编译依赖。（仓库源在 `settings.gradle.kts`）
4. 菜单 **Build > Build Bundle(s) / APK(s) > Build APK(s)**。
5. APK 路径：`app/build/outputs/apk/debug/app-debug.apk`。
6. 通过 Wear OS 无线调试 / Android Studio 配对安装到手表，安装后在手表长按当前表盘选择此表盘。

注意：当前环境缺少 Android SDK/Gradle，已生成可编辑 Android Studio 项目，但未在真实 Watch8 上运行/编译验证。

## 设置应用快捷入口
1. 安装并设为当前表盘后，**长按表盘** → **自定义 / Customize**。
2. 进入 **Complications / 数据 / 快捷项**，点选一个彩色方格（共 8 个）。
3. 选择 **App shortcut / 应用快捷方式**，再选择手表上需要打开的 App。
4. 每个方格分别设置；返回表盘后**轻触图标**即可打开对应程序。

若编辑器中的名称、选项不同，以手表系统提供的名称为准。若某 App 无法作为快捷项出现，这取决于该设备/对应应用提供的功能。

## 工程说明
- AndroidManifest.xml 声明 `hasCode=false` 和 WFF 2；WFF 系统服务直接绘制，没有后台 Java/Kotlin 代码。
- `res/raw/watchface.xml` 定义日期、数字时间、8 个 complication 和电池。
- `res/drawable-nodpi/tile_1..8.png` 是 8 个彩色圆角块。
- `res/drawable-nodpi/add_plus.png` 是未选择应用前的加号。
- `res/drawable-nodpi/preview.png` 是首次安装的静态预览（示例时间和电量，不代表静态显示）。
- 原生 WFF 上限为 **8 个可配置 complication**，因此此版本为 4×2。

## 权威文档
- WFF：https://developer.android.com/training/wearables/wff
- Complications：https://developer.android.com/training/wearables/wff/complications
- WatchFaceInfo：https://developer.android.com/training/wearables/wff/setup
- APP_SHORTCUT：https://developer.android.com/reference/wear-os/wff/complication/default-provider-policy
