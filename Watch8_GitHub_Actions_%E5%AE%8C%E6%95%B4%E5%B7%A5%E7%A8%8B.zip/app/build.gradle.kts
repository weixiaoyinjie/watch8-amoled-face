plugins { id("com.android.application") }

android {
    namespace = "com.local.watch8.amoledshortcuts"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.local.watch8.amoledshortcuts"
        minSdk = 34
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            isShrinkResources = false
        }
        getByName("debug") {
            isMinifyEnabled = false
        }
    }
}
